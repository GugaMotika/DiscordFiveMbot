module.exports = {
  name: 'ocisti',
  description: 'Ocisti poruke u chat!',
  execute(message, args){
      if (!message.member.hasPermission("MANAGE_MESSAGES"))
  return message.reply("Nemas permisije za tu komandu!.").then((msg) => {
    msg.delete({ timeout: 2000});
});
if (!args[0]) return message.channel.send("You need to speficy a value (1-99)");
message.channel.bulkDelete(args[0]).then(() => {
  message.channel
    .send(`Ocisceno ${args[0]} poruka.`)
    .then((msg) => {
          msg.delete({ timeout: 2000});
    });
});
  }, 
};