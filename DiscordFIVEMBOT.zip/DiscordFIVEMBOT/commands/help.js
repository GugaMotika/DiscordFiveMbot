  
const pagination = require('discord.js-pagination');
const Discord = require('discord.js');
let config = require('../config.json');
module.exports = {
    name: 'pomoc',
    description: 'Pomoc komanda',
    execute(message, args){
        const Fivem = new Discord.MessageEmbed()
        .setTitle('FiveM')
        .setColor('#ffaa17')
        .addField(`${config.PREFIX}status`, 'Vidi server statis')
        .addField(`${config.PREFIX}igraci`, 'Vidi ko je sve konktan na server')
        .addField(`${config.PREFIX}prijedlog`, 'Napisi prijedlog serveru')
        .setTimestamp()

        const fun = new Discord.MessageEmbed()
        .setTitle('Zabava')
        .setColor('#1764ff')
        .addField(`${config.PREFIX}meme`, 'Posalje random meem')
        .addField(`${config.PREFIX}cat`, 'Posalje sliku random macke')
        .setTimestamp()

        const utility = new Discord.MessageEmbed()
        .setTitle('Mogucnosti')
        .setColor('#9500f2')
        .addField(`${config.PREFIX}ping`, 'Pong')
        .setTimestamp()

        const pages = [
                Fivem,
                fun,
                utility
        ]

        const emojiList = ["⏪", "⏩"];

        const timeout = '120000';

        pagination(message, pages, emojiList, timeout)
    }, 
};