const Discord = require('discord.js');
const axios = require('axios');
let config = require('../config.json');
module.exports = {
    name: 'macka',
    description: 'Macka Command',
     async execute(message, args){
    
        if(message.channel.id === config.CHANNELS_ID.ANIMALS){

            const url = 'https://some-random-api.ml/img/cat';

            let data, response;
            try {
                response = await axios.get(url);
                data = response.data;
            } catch (e) {
                return message.channel.send(`Pogreska pokusaj opet!`)
            }
    
            const embed = new Discord.MessageEmbed()
                .setTitle(`Random Cat: `)
                .setColor('#f3f3f3')
                .setImage(data.link)
    
            await message.channel.send(embed)

        }
        else{
            message.delete();

            let wEmbed = new Discord.MessageEmbed()
            .setTitle("Ups!")
            .setColor("#fc2403")
            .setDescription(`Krivi kanal za macke koristi <#${config.CHANNELS_ID.ANIMALS}> ovaj umjesto`);
            message.channel.send(wEmbed).then((wmsg) =>{
              setTimeout(() =>{
                wmsg.delete();
              },4000);
           });
        }

        

    }, 
};